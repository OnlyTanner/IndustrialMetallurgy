package com.onlytanner.test.proxy;

public interface CommonProxy 
{
	public void init();
}

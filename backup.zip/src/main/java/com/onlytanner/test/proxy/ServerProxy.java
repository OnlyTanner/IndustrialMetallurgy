package com.onlytanner.test.proxy;

public class ServerProxy implements CommonProxy 
{
	@Override
	public void init() {}
}
